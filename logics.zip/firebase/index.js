"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.keyExists = exports.addKey = exports.getAllKeys = exports.db = void 0;
// Import the functions you need from the SDKs you need
const app_1 = require("firebase/app");
const firestore_1 = require("firebase/firestore");
const firebaseConfig = {
    apiKey: "AIzaSyBljO5v9LTt51gMSd85Mg_6Os7aOZRtTj8",
    authDomain: "pixout-66b72.firebaseapp.com",
    projectId: "pixout-66b72",
    storageBucket: "pixout-66b72.appspot.com",
    messagingSenderId: "214892143314",
    appId: "1:214892143314:web:9c77f5f92f59d633f5430b",
    measurementId: "G-GHVMDNMSKJ",
};
const firebaseApp = (0, app_1.initializeApp)(firebaseConfig);
const db = (0, firestore_1.getFirestore)(firebaseApp);
exports.db = db;
function keyExists(key) {
    return __awaiter(this, void 0, void 0, function* () {
        const q = (0, firestore_1.query)((0, firestore_1.collection)(db, "keys"), (0, firestore_1.where)("key", "==", key));
        const querySnapshot = yield (0, firestore_1.getDocs)(q);
        return !querySnapshot.empty;
    });
}
exports.keyExists = keyExists;
function addKey(key, typeKey) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield (0, firestore_1.addDoc)((0, firestore_1.collection)(db, "keys"), {
                key: key,
                type_key: typeKey,
            });
            console.log("Chave adicionada com sucesso.");
        }
        catch (error) {
            console.error("Erro ao adicionar chave: ", error);
        }
    });
}
exports.addKey = addKey;
// Função para retornar todas as chaves
function getAllKeys() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const querySnapshot = yield (0, firestore_1.getDocs)((0, firestore_1.collection)(db, "keys"));
            const keys = [];
            querySnapshot.forEach((doc) => {
                const data = doc.data();
                keys.push({
                    key: data.key,
                    type_key: data.type_key,
                });
            });
            return keys;
        }
        catch (error) {
            console.error("Erro ao obter chaves: ", error);
            return [];
        }
    });
}
exports.getAllKeys = getAllKeys;
