"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const https_1 = __importDefault(require("https"));
const firebase_1 = require("./firebase");
const API = "ws.suitpay.app";
const API_PATH = "/api/v1/gateway/pix-payment";
const CI = "jhonnydigital_1706710143331";
const CS = "e9e1b363694587acd34a0390ea13bd4215270b7ca6f558a5cbf6c9ae46a9e2f9db6b557eeacf4d69947f919ffd562a01";
const VALUE = 0.05;
const create = (req, res) => {
    const value = Number(VALUE);
    const ci = CI;
    const cs = CS;
    const newKey = Object.assign(Object.assign({}, req.body), { createdAt: new Date() });
    const postData = JSON.stringify({
        value,
        key: req.body.key,
        typeKey: req.body.typeKey,
    });
    const options = {
        hostname: API,
        port: 443,
        path: API_PATH,
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Content-Length": postData.length,
            ci: ci,
            cs: cs,
        },
    };
    const externalRequest = https_1.default.request(options, (externalRes) => {
        let body = "";
        externalRes.on("data", (chunk) => {
            body += chunk;
        });
        externalRes.on("end", () => __awaiter(void 0, void 0, void 0, function* () {
            const responseBody = JSON.parse(body);
            if (responseBody.response === "OK") {
                yield (0, firebase_1.addKey)(req.body.key, req.body.typeKey);
                res.status(201).json(responseBody);
            }
            else {
                res.status(500).json({ message: responseBody.message });
            }
        }));
    });
    externalRequest.on("error", (e) => {
        console.error(`Problem with request: ${e.message}`);
        res.status(500).json({ message: "Erro na requisição externa" });
    });
    externalRequest.write(postData);
    externalRequest.end();
};
const read = (_req, res) => __awaiter(void 0, void 0, void 0, function* () {
    // const queryResult: QueryResult = await client.query("SELECT * FROM keys;");
    return res.status(200).json(yield (0, firebase_1.getAllKeys)());
});
exports.default = { create, read };
